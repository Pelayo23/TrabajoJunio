<div class="container">
  <footer>
    <p class="text-center">Tienda de camisetas de baloncesto</p>
    <p class="text-center">Diseñada por Pelayo Garrido del Valle</p>
  </footer>
</div>
<style>
footer {
    background-color: #333;
    color: #fff;
    position: fixed;
    bottom: 0;
    width: 100%;
    padding: 10px;
    text-align: center;
    z-index: 1000;
}

.container {
  margin: 0 auto;
  height: 75px;
  max-width: none;
  width: 1536px;
  text-align: center;
  background-color: rgba(0,0,0,0);
}